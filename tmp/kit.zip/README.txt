Contractor Estimate & Invoice Kit
=================================

Thank you for your purchase!

FILES
- Contractor_Estimate_Invoice_Kit_Blank.xlsx   ... ready to use (empty)
- Contractor_Estimate_Invoice_Kit_Sample.xlsx  ... filled-in example (bathroom remodel) to see how it works

OPEN IN EXCEL
Just double-click the .xlsx file.

OPEN IN GOOGLE SHEETS
1. Go to drive.google.com and click New > File upload.
2. Upload the .xlsx file, then double-click it.
3. Click "Open with Google Sheets" (or File > Save as Google Sheets).

START HERE
Open the "How to use" tab first. Type only in the yellow cells.
Order of work: Settings > Estimate > Quote (send to client) > Invoice > Job Tracker.

NOTE
This template helps you organize your numbers. It is not tax, legal or accounting advice.
Sales tax rules differ by location - please check your local rules.

License: for use in your own business. Please do not resell or share the files.
